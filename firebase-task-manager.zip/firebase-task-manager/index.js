const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

exports.notifyTaskStatusChange = functions.firestore
  .document("tasks/{taskId}")
  .onUpdate(async (change, context) => {
    const newValue = change.after.data();
    const previousValue = change.before.data();

    // Only send notifications when status changes to "completed"
    if (newValue.status === "completed" && previousValue.status !== "completed") {
      const payload = {
        notification: {
          title: "Task Completed",
          body: `Task "${newValue.title}" is completed!`
        }
      };

      const userId = newValue.userId;
      const userRef = admin.firestore().collection("users").doc(userId);
      const userDoc = await userRef.get();

      if (userDoc.exists && userDoc.data().fcmToken) {
        await admin.messaging().sendToDevice(userDoc.data().fcmToken, payload);
      }
    }
  });
