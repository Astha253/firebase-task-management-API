// server.js

const express = require('express');
const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json'); 
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  projectId: "real-time-task-management-api",
  databaseURL: "https://real-time-task-management-api.firebaseio.com"
});

// Firestore database reference
const db = admin.firestore();


 
app.post('/tasks', async (req, res) => {
    const { title, description, status, dueDate, userId } = req.body;
    try {
      const task = await db.collection('tasks').add({
        title,
        description,
        status: status || 'pending',
        dueDate: dueDate ? admin.firestore.Timestamp.fromDate(new Date(dueDate)) : null,
        userId
      });
      res.status(201).send({ id: task.id });
    } catch (error) {
      res.status(400).send(error.message);
    }
  });

app.patch('/tasks/:id', async (req, res) => {
    const { status } = req.body;
    try {
      const taskRef = db.collection('tasks').doc(req.params.id);
      await taskRef.update({ status });
      res.status(200).send('Task updated successfully');
    } catch (error) {
      res.status(400).send(error.message);
    }
  });
  
app.get('/tasks', async (req, res) => {
    try {
      const snapshot = await db.collection('tasks').get();
      const tasks = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.status(200).json(tasks);
    } catch (error) {
      res.status(400).send(error.message);
    }
  });
    
  app.listen(3000, () => {
    console.log('Server is running on port 3000');
  });